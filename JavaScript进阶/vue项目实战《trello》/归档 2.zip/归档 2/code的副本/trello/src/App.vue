<template>
  <div id="app">
    <router-view></router-view>
    <!-- <router-link to="/a" tag="span">a组件</router-link>
    <br>
    <router-link to="/b">b组件</router-link> -->
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
export default {
  name: 'app',
  components: {
  }
}
</script>

<style>
@import url("./assets/font/style.css");
#app{
  position: relative;
}
/* #app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
} */
</style>

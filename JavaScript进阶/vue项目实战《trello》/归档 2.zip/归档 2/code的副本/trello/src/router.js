import Router from 'vue-router'
import Vue from 'vue'
Vue.use(Router);
// import A from './components/A'
// import B from './components/B'
export default new Router({
    mode: "history",
    routes: [
        {
            path: "/",
            redirect: "/login"
        },
        {
            path: "/login",
            component: ()=>import("./views/Login")
        },
        {
            path: "/register",
            component:()=>import("./views/Register")
        },
        {
            path:"/trello",
            component:()=>import('./views/Trello')
        }
    ]

})
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    // num:1,
    // money:10
    list: []
  },
  getters: {
    // mymoney:state=>{
    //     return "$"+state.money;
    // }
  },
  mutations: {
    // increment(state,addNum){
    //   state.num = state.num +addNum;
    // }
    getData(state, list) {
      state.list = list;
    }
  },
  actions: {
    // // 异步操作
    // increment(context,addNum){
    //   context.commit("increment",addNum)
    // }
    getData(context) {
      Vue.prototype.$http.get("http://localhost:3000/list").then(res => {
        console.log(res);
        context.commit("getData", res.data);
      })
    },
    updateSort(context, data) {
      // 更新排序；
      Vue.prototype.$http.put("http://localhost:3000/updateSort",data).then(res => {
        console.log(res);
      })
    }
  }
})

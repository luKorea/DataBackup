<template>
 <div>
        <div class="container">
            <p v-show="messageData" class="message">{{messageInfo}}</p>
            <h1 class="titleCss">登录到Trello</h1>
            <a class="loginCss" href="/register">或者创建账户</a>
            <div class="inputCss">
                <label for="username">账号</label>
                <input id="username" v-model="users.username" placeholder="你的用户名" type="inputType" />
            </div>
            <div class="inputCss">
                <label for="pwd">密码</label>
                <input id="pwd" v-model="users.pwd" placeholder="你的密码" type="password" />
            </div>
            <input class="button button-green" @click="sub"  type="button" value="登录" />
          <!-- <button @click="test">点击我发送请求</button> -->
        </div>
    </div>
</template>

<script>
 export default {
   data () {
     return {
       messageData:false,
       messageInfo:"",
       users:{
         username:"",
         pwd:""
       }
     }
   },
   components: {

   },
  methods: {
    sub(){
        this.$http.post("http://localhost:3000/checkUsers",this.users).then(res=>{
          console.log(res);
          if(res.data.status==0){
            // 跳转到主页
            console.log("跳转主页");
            //缓存token
            localStorage.setItem("mytoken",res.data.token);
            this.$router.push("/trello");
          }else{
            this.messageData = true;
            this.messageInfo = res.data.info;
          }
        })
    },
    // test(){
    //   this.$http.post("http://localhost:3000/test").then(res=>{
    //         console.log(res);
    //   })
    // }
  }
 }
</script>

<style scoped>

.container {
    font-size: 16px;
    font-weight: 300;
    width: 540px;
    margin: 0 auto;
    margin-top: 30px;
  }
  .loginCss {
    color: #298fca;
    font-size: 18px;
  }
  .titleCss {
    font-size: 38px;
    line-height: 48px;
    margin-top: 0px;
    margin-bottom: 0px;
  }
  .button {
    border-radius: 3px;
    max-width: 440px;
    width: 100%;
    background: #e2e4e6;
    box-shadow: none;
    color: hsl(0, 0%, 55%);
    cursor: default;
    padding: 0.6em 1.3em;
    font-weight: bold;
    display: inline-block;
    text-decoration: none;
    border: 0px;
    height: 40px;
    font-size: 16px;
    margin-top: 20px;
  }
  
  /* 符合条件后的按钮 */
  .button-green {
    background: #61bd4f;
    color: white;
  }
  .button-green:hover {
    background: #5aac44;
  }
  .message {
    background: #eb5a46;
    color: #fbedeb;
    font-size: 14px;
    font-family: "Helvetica Neue", Arial, sans-serif;
    border-radius: 4px;
    padding: 10px;
    width: 440px;
  }

  label{
    display: block;
}
.inputCss{
    margin-top: 30px;
}
.inputCss label{
   margin-bottom: 10px;

}
.inputCss input{
    background: #EDEFF0;
    border-radius: 4px;
    border: 1px solid #CDD2D4;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    padding: .5em;
    max-width: 440px;
    width: 100%;
    display: block;
    margin: 0 0 1.2em;
    height: 40px;
}
</style>

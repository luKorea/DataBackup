<template>
  <div class="container">
    <!-- <h1>{{$store.state.num}}</h1>
    <h2>{{$store.getters.mymoney}}</h2>-->
    <!-- <h2>{{mymoney}}</h2>
    <button @click="changeState">点击</button>-->
    <!-- {{list}} -->
    <MyHead></MyHead>
    <SubTitle></SubTitle>
    <ul class="plan-list">
      <ListItem
        v-for="(item,key) in list"
        :key="key"
        :item="item"
        @checkCrash="checkCrash"
        @checkTaskCrash="checkTaskCrash"
        ref="listWrap"
      ></ListItem>
      <!-- <ListItem></ListItem> -->
      <li class="list-wrap">
        <a href="javascript:;" class="add-list">
          <i class="iconfont icon-kuaijietongdao"></i>
          <span>添加列表</span>
        </a>
      </li>
    </ul>
  </div>
</template>

<script>
import MyHead from "@/components/trello/MyHead.vue";
import SubTitle from "@/components/trello/SubTitle.vue";
import ListItem from "@/components/trello/ListItem.vue";
// import {mapGetters} from 'vuex';
import { mapState } from "vuex";
export default {
  data() {
    return {};
  },
  created() {
    this.$store.dispatch("getData");
  },
  components: {
    MyHead,
    SubTitle,
    ListItem
  },
  methods: {
    //   changeState(){
    //     //   this.$store.commit("increment",2)
    //     this.$store.dispatch("increment",2);
    //   }
    checkCrash(target, listWrapOriginal) {
      // console.log(this.$refs['listWrap']);
      let listWraps = this.$refs["listWrap"];
      for (let i = 0; i < listWraps.length; i++) {
        if (listWraps[i].$el != listWrapOriginal) {
          // 如果不是自身 检测碰撞
          let res = this.isButt(listWraps[i].$el, target);
          if (res && res.isHalf) {
            //  交换背景和 被碰撞元素的位置；
            this.exchange(listWraps[i].$el, listWrapOriginal);

            // 数据更新
            let id1 = listWrapOriginal.querySelector(".listid").value;
            let sortid1 = listWrapOriginal.querySelector(".listsortid").value;
            let id2 = listWraps[i].$el.querySelector(".listid").value;
            let sortid2 = listWraps[i].$el.querySelector(".listsortid").value;
            let obj = {
              id1,
              id2,
              sortid1,
              sortid2
            };
            console.log(obj);
            this.$store.dispatch("updateSort", obj);
          }
        }
      }
    },
    checkTaskCrash(target, listWrapOriginal, dd) {
      let listWraps = this.$refs["listWrap"];
      for (let i = 0; i < listWraps.length; i++) {
        if (listWraps[i].$el != listWrapOriginal) {
          // 如果不是自身 检测碰撞
          let res = this.isButt(listWraps[i].$el, target);
          if (res && res.isHalf) {
            //获取listWrap下面的任务；
            let sublist = listWraps[i].$el.getElementsByClassName("sublist")[0];
            let taskEles = sublist.getElementsByClassName("item");
            if (taskEles.length > 0) {
              //有任务
              for (let i = 0; i < taskEles.length; i++) {
                if (taskEles[i] !== target) {
                  let result = this.isButt(taskEles[i], target);
                  if (result && result.isHalf) {
                    if (result.direction == "up") {
                      sublist.insertBefore(dd, taskEles[i]);
                    } else {
                      sublist.insertBefore(dd, taskEles[i].nextSibling);
                    }
                    break;
                  }else{
                      sublist.insertBefore(dd,sublist.getElementsByClassName("add")[0]);
                  }
                }
              }
            } else {
              //没有任务
              sublist.insertBefore(
                dd,
                sublist.getElementsByClassName("add")[0]
              );
            }
            break;
          }
        }
      }
    },
    exchange(ele1, ele2) {
      let ep1 = ele1.parentNode;
      let ep2 = ele2.parentNode;
      // console.log(ep1.children)
      let index1 = [...ep1.children].indexOf(ele1);
      let index2 = [...ep2.children].indexOf(ele2);
      ep2.insertBefore(ele1, ep2.children[index2]);
      ep1.insertBefore(ele2, ep1.children[index1]);
    },
    isButt(aObj, bObj) {
      let { left: aleft, top: atop } = aObj.getBoundingClientRect();
      let { left: bleft, top: btop } = bObj.getBoundingClientRect();

      // a相关
      let axmin = aleft;
      let axmax = aleft + aObj.offsetWidth;
      let aymin = atop;
      let aymax = atop + aObj.offsetHeight;

      //b相关；
      let bxmin = bleft;
      let bxmax = bleft + bObj.offsetWidth;
      let bymin = btop;
      let bymax = btop + bObj.offsetHeight;

      if (axmax > bxmin && axmin < bxmax && aymax > bymin && aymin < bymax) {
        // console.log("碰撞了！！！")
        // 在x轴上判断碰撞是否过半；
        let isHalf;
        let direction;
        if (bxmax > axmax) {
          // console.log("左")
          isHalf = axmax - bxmin > aObj.offsetWidth / 2 ? true : false;
        } else {
          //  console.log("右")
          isHalf = bxmax - axmin > aObj.offsetWidth / 2 ? true : false;
        }
        // console.log(isHalf);

        let centerAY = aObj.offsetHeight / 2 + aymin;
        let centerBY = bObj.offsetHeight / 2 + bymin;
        if (centerAY < centerBY) {
          direction = "down";
        } else {
          direction = "up";
        }

        return {
          isHalf,
          direction
        };
      }
    }
  },
  computed: {
    //   ...mapGetters(['mymoney']),
    ...mapState(["list"])
  }
};
</script>

<style scoped>
.container {
  background: #4bbf6c;
  height: 100vh;
  overflow-y: hidden;
}
.plan-list {
  overflow-x: scroll;
  overflow-y: hidden;
  display: flex;
  height: 100%;
}

.add a {
  display: block;
  color: #6b778c;
}
.add-list {
  display: block;
  width: 264px;
  height: 32px;
  line-height: 32px;
  padding: 4px;
  background: rgba(0, 0, 0, 0.15);
  border-radius: 5px;
  text-indent: 10px;
}
</style>
